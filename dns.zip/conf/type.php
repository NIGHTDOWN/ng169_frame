<?php

return array(
	'mobiletype'=>
	array(
		1=>'android',
		2=>'ios',
		3=>'web',
		4=>'winphone',
	),
	'paytype'=>
	array(
		1=>'iphone pay',
		2=>'google pay',
		3=>'PayPal',
           
	),
	'viptype'=>
	array(
		1=>'普通',
		2=>'VIP-1月',
		3=>'VIP-3月',
		4=>'VIP-6月',
		5=>'VIP-12月',
      
	)
	,
	'paystatus'=>
	array(
		0=>'待支付',
		1=>'支付完成',
		2=>'取消支付',
	)
	,
	'gender'=>
	array(
		
		1=>'男',
		2=>'女',
	)
	,
	'gift'=>
	array(
		1=>'Kiss',
		2=>'Rectangle',
		3=>'Wine',
		4=>'Rose',
		5=>'Lipstick',
		6=>'Perfume',
		7=>'High heels',
		8=>'Diamond',
	)
	
);

?>
