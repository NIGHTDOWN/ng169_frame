<?php

return array(
            'main'=>
            array('host'=>'192.168.6.69',
                    'num'=>'1',
                    'port'=>'6379',
                    'pwd'=>'123456',
                    'pre'=>'ng169_',
                    'charset'=>'utf8',
                    'timeout'=>'604800‬'//过期时间一周
                    )

    );

?>
