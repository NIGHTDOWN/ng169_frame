<?php
	
	 return array(
	'main'=>
	array('dbhost'=>'127.0.0.1',
	'dbname'=>'dns',
	'dbuser'=>'root',
	'dbpwd'=>'root',
	'dbpre'=>'bb_',
	'charset'=>'utf8'
	)

	);

	?>
	