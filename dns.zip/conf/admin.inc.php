<?php
return 
[
   
    'admins' => 
        [
            'alias' => '管理员管理',
            'action' => 
                [
                    'run' => 
                        [
                            'alias' => '列表',
                            'seo' => '1',
                        ],
                    'add_view' => 
                        [
                            'alias' => '添加',
                            'seo' => '1',
                        ],
                    'show' => 
                        [
                            'alias' => '详情',
                            'seo' => '1',
                        ],
                    'add' => 
                        [
                            'alias' => '添加',
                            'seo' => '1',
                        ],
                    'save' => 
                        [
                            'alias' => '保存',
                            'seo' => '1',
                        ],
                    'cgthispwd' => 
                        [
                            'alias' => '修改密码',
                            'seo' => '1',
                        ],
                    'del' => 
                        [
                            'alias' => '删除',
                            'seo' => '1',
                        ],
                    'cgpwd' => 
                        [
                            'alias' => '修改所有管理员密码',
                            'seo' => '1',
                        ]
                ]
        ],
  
    'ajax' => 
        [
            'alias' => '',
            'action' => 
                [
                    'run' => 
                        [
                            'alias' => '列表',
                            'seo' => '1',
                        ]
                ]
        ],
   
    'domian' => 
        [
            'alias' => '域名管理',
            'action' => 
                [
                    'run' => 
                        [
                            'alias' => '列表',
                            'seo' => '1',
                        ],
                    'add' => 
                        [
                            'alias' => '添加',
                            'seo' => '1',
                        ],
                    'del' => 
                        [
                            'alias' => '删除',
                            'seo' => '1',
                        ],
                    'edit' => 
                        [
                            'alias' => '编辑',
                            'seo' => '1',
                        ]
                ]
        ],
    
    'frame' => 
        [
            'alias' => '',
            'action' => 
                [
                    'run' => 
                        [
                            'alias' => '列表',
                            'seo' => '1',
                        ],
                    'main' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ]
                ]
        ],
    'login' => 
        [
            'alias' => '',
            'action' => 
                [
                    'run' => 
                        [
                            'alias' => '列表',
                            'seo' => '1',
                        ],
                    'login' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ],
                    'logout' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ]
                ]
        ],
    'role' => 
        [
            'alias' => '权限管理',
            'action' => 
                [
                    'add' => 
                        [
                            'alias' => '添加',
                            'seo' => '1',
                        ],
                    'run' => 
                        [
                            'alias' => '列表',
                            'seo' => '1',
                        ],
                    'show' => 
                        [
                            'alias' => '详情',
                            'seo' => '1',
                        ],
                        'show' => 
                        [
                            'alias' => '删除',
                            'seo' => '1',
                        ]
                ]
        ],
   
    'siteset' => 
        [
            'alias' => '系统设置',
            'action' => 
                [
                    'sock' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ],
                    'closesock' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ],
                    'tz' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ],
                    'clearcache' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ],
                    'updatecache' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ],
                    'smsset' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ],
                    'withdraw' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ],
                    'smsset_getnum' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ],
                    'smsset_try' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ],
                    'mailset' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ],
                    'mailset_try' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ],
                    'seo' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ],
                    'upset' => 
                        [
                            'alias' => '上传设置',
                            'seo' => '1',
                        ],
                    'run' => 
                        [
                            'alias' => '系统设置',
                            'seo' => '1',
                        ],
                    'order' => 
                        [
                            'alias' => '其他设置',
                            'seo' => '1',
                        ],
                    'save' => 
                        [
                            'alias' => '保存',
                            'seo' => '1',
                        ]
                ]
        ],
    'upimg' => 
        [
            'alias' => '',
            'action' => 
                [
                    'run' => 
                        [
                            'alias' => '列表',
                            'seo' => '1',
                        ],
                    'file' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ],
                    'json_up' => 
                        [
                            'alias' => '',
                            'seo' => '1',
                        ]
                ]
        ]
]
?>