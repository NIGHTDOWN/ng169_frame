<?php

return array(
            'main'=>
            array('app_id'=>'2288795978115782',//appid
                    'app_secret'=>'016c35bee661c25afd34c232cf61750e',//app_secret
                    'LoginUrl'=>'https://192.168.6.69/api/login/back',//回调链接
                   
                    )

    );

?>
