<?php





namespace ng169\sock;
use ng169\Y;
use ng169\lib\Socket;

class adminSock extends   Socket{
	public $admin='';
	public $socket;
	
}

?>
