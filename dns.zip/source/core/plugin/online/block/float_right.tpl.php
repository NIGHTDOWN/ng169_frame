<?php



if(!defined('IN_OECMS')) {
	exit('Access Denied');
}


;echo '<script language="javascript" type="text/javascript">
function Mouseclose(){
	document.getElementById(\'floatDivr\').style.display=\'none\';
}
window.onload = function(){
	var floatObjr = document.getElementById(\'floatDivr\');
	Floaters.addItem(floatObjr, screen.width-'; echo $online['right_rightpr'];;echo ', '; echo $online['right_toppr'];;echo ');
	Floaters.sPlay();
	document.getElementById(\'floatDivr\').style.display=\'block\';
}
</script>';?>
